<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	
	public function index()
	{
		$data['title'] = 'Home | ';
		$data['phone'] = '';
		$data['mail'] = '';
		$data['keyword'] = '';
		$data['description'] = '';
		$this->load->view('home',$data);
	}
	
	public function service()
	{
		$data['title'] = '';
		$data['phone'] = '';
		$data['mail'] = '';
		$data['keyword'] = '';
		$data['description'] = '';
		$this->load->view('service',$data);
	}

	public function team()
	{
		$data['title'] = '';
		$data['phone'] = '';
		$data['mail'] = '';
		$data['keyword'] = '';
		$data['description'] = '';
		$this->load->view('team',$data);
	}

	public function portfolio()
	{
		$data['title'] = '';
		$data['phone'] = '';
		$data['mail'] = '';
		$data['keyword'] = '';
		$data['description'] = '';
		$this->load->view('portfolio',$data);
	}

	public function contact()
	{
		
		$this->load->view('contact');
	}
}