<script src="<?= base_url() ?>assets/js/jquery-3.6.1.min.js.js"></script><!-- JQUERY.MIN JS -->
<script src="<?= base_url() ?>assets/js/popper.min.js"></script><!-- POPPER.MIN JS -->
<script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->
<script src="<?= base_url() ?>assets/js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->
<script src="<?= base_url() ?>assets/js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script src="<?= base_url() ?>assets/js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script src="<?= base_url() ?>assets/js/waypoints-sticky.min.js"></script><!-- sticky header JS -->
<script src="<?= base_url() ?>assets/js/isotope.pkgd.min.js"></script><!-- MASONRY  -->
<script src="<?= base_url() ?>assets/js/imagesloaded.pkgd.min.js"></script><!-- MASONRY  -->
<script src="<?= base_url() ?>assets/js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->
<script src="<?= base_url() ?>assets/js/theia-sticky-sidebar.js"></script>
<!--sticky content-->
<script src="<?= base_url() ?>assets/js/wow.js"></script><!-- WOW JS -->
<script src="<?= base_url() ?>assets/js/lc_lightbox.lite.js"></script><!-- IMAGE POPUP -->
<script src="<?= base_url() ?>assets/js/swiper-bundle.min.js"></script><!-- Swiper js -->
<script src="<?= base_url() ?>assets/js/custom.js"></script><!-- CUSTOM FUCTIONS  -->