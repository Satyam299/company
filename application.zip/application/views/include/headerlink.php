<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>
    <?php $title ?>
</title>
<link rel="stylesheet" href="<?= base_url() ?>assets/css/bootstrap.min.css"><!-- BOOTSTRAP STYLE SHEET -->
<link rel="stylesheet" href="<?= base_url() ?>assets/css/fontawesome/css/font-awesome.min.css">
<!-- FONTAWESOME STYLE SHEET -->
<link rel="stylesheet" href="<?= base_url() ?>assets/css/owl.carousel.min.css"><!-- OWL CAROUSEL STYLE SHEET -->
<link rel="stylesheet" href="<?= base_url() ?>assets/css/magnific-popup.min.css"><!-- MAGNIFIC POPUP STYLE SHEET -->
<link rel="stylesheet" href="<?= base_url() ?>assets/css/loader.min.css"><!-- LOADER STYLE SHEET -->
<link rel="stylesheet" href="<?= base_url() ?>assets/css/flaticon.min.css"><!-- FLATICON STYLE SHEET -->
<link rel="stylesheet" href="<?= base_url() ?>assets/css/animate.css"><!-- WOW ANIMATE STYLE SHEET -->
<link rel="stylesheet" href="<?= base_url() ?>assets/css/feather.css"><!-- Feather STYLE SHEET -->
<link rel="stylesheet" href="<?= base_url() ?>assets/css/lc_lightbox.css"><!-- IMAGE POPUP -->
<link rel="stylesheet" href="<?= base_url() ?>assets/css/swiper-bundle.min.css"><!-- SWIPER SLIDER CSS -->
<link rel="stylesheet" href="<?= base_url() ?>assets/css/style.css"><!-- MAIN STYLE SHEET -->